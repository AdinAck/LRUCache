# LRUCache
A simple, adaptive LRU cache with an extendable interface.

Refer to `main.ipynb` for information.